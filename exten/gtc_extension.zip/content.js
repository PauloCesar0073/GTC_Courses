function extrairArquivos(arquivos) {
  const files = [];

  if (arquivos && typeof arquivos === 'object') {
    const parsedFiles = Array.isArray(arquivos) ? arquivos : [arquivos];

    parsedFiles.forEach(dicio => {
      const externalUrl = dicio.external_url;
      const downloadUrls = dicio.download_urls;

      if (externalUrl) {
        files.push(`<a href="${externalUrl}" target="_blank">URL Externa</a>`);
      }
      if (downloadUrls) {
        for (const file_type in downloadUrls) {
          if (Object.prototype.hasOwnProperty.call(downloadUrls, file_type)) {
            const file_list = downloadUrls[file_type];
            for (const file_info of file_list) {
              const file_link = file_info.file;
              if (file_link) {
                files.push(`<a href="${file_link}" target="_blank">Download do Arquivo</a>`);
              }
            }
          }
        }
      }
    });
  } else {
    console.error('O parâmetro "arquivos" não é um objeto válido.');
  }

  return files;
}


function obterArtigos(id_asset, id_curso, id_lecture,title) {
  const apiUrl = `https://www.udemy.com/api-2.0/assets/${id_asset}/?fields[asset]=@min,status,delayed_asset_message,processing_errors,body&course_id=${id_curso}&lecture_id=${id_lecture}`;

  fetch(apiUrl)
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
      });
  }
  return response.json();
    })
    .then(data => {
      // Verifica se há conteúdo recebido da API
      if (data && data.body) {
        const texto = data.body; // Obtém o conteúdo do corpo
        criarArquivoHTML(texto,title)

      }
    })
    .catch(error => {
      console.error('Erro:', error);
      // Lógica para lidar com erros na requisição
    });
}

function converterHTMLParaTexto(html) {
  // Cria um elemento div temporário
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = html;

  // Obtém o texto do elemento
  const textoNormal = tempDiv.textContent || tempDiv.innerText || '';

  return textoNormal;
}

function obterFiles(idCurso, idLecture, idAsset, title) {
  const apiUrl = `https://www.udemy.com/api-2.0/users/me/subscribed-courses/${idCurso}/lectures/${idLecture}/supplementary-assets/${idAsset}/?fields[asset]=download_urls`;

  fetch(apiUrl)
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
      });
  }
  return response.json();
    })
    .then(data => {
      // Imprime o resultado completo da requisição
      const parsedData = data;
      const download_urls = parsedData.download_urls;

      if (download_urls && download_urls.File && download_urls.File.length > 0) {
        const cc = download_urls.File[0].file;
        if (cc) {
          downloadFiles(cc, title);
          
        }
      } else if (download_urls && download_urls.Presentation && download_urls.Presentation.length > 0) {
        const presentation = download_urls.Presentation[0].file;
        if (presentation) {
          downloadFiles(presentation,title)

         
        }
      } else {
       
      }
    })
    .catch(error => {
      document.getElementById('painel_').innerText = `Ocorreu um erro ao buscar os cursos. -> ${error}`;
    });
}

function downloadFiles(url, title) {
  fetch(url)
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
      });
  }
      return response.blob(); // Obtém a resposta como um Blob
    })
    .then(blobData => {
      // Cria um URL temporário para o Blob
      const blobUrl = URL.createObjectURL(blobData);

      // Cria um link para download do arquivo
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = title || 'file'; // Nome do arquivo a ser baixado (se não houver título, usa 'file')
      link.click();

      // Limpa o URL temporário após o download do arquivo
      URL.revokeObjectURL(blobUrl);
    })
    .catch(error => {
      console.error('Erro:', error);
      // Lógica para lidar com erros no processo de download de arquivos
    });
}


function createStyledButton(text) {
  const linksButton = document.createElement('button');
  linksButton.textContent = text;

  linksButton.style.padding = '10px 20px';
  linksButton.style.width = '650px'; // Largura do botão
  linksButton.style.height = '60px';
  linksButton.style.backgroundColor = 'grey';
  linksButton.style.color = '#fff';
  linksButton.style.border = 'none';
  linksButton.style.borderRadius = '5px';
  linksButton.style.cursor = 'pointer';
  linksButton.style.fontFamily = 'Arial, sans-serif';
  linksButton.style.fontSize = '16px';

  // Evento quando o mouse passa sobre o botão
  linksButton.addEventListener('mouseover', function() {
    linksButton.style.backgroundColor = '#ff7f50'; // Altera a cor de fundo ao passar o mouse
    linksButton.style.color = '#000'; // Altera a cor do texto ao passar o mouse
  });

  // Evento quando o mouse sai do botão
  linksButton.addEventListener('mouseleave', function() {
    linksButton.style.backgroundColor = 'grey'; // Cor de fundo original
    linksButton.style.color = '#fff'; // Cor do texto original
    
  });

  return linksButton;
}


function obterVideos(idCurso, idLecture,title) {
  const apiUrl = `https://www.udemy.com/api-2.0/users/me/subscribed-courses/${idCurso}/lectures/${idLecture}/?fields[lecture]=asset,description,download_url,is_free,last_watched_second&fields[asset]=asset_type,length,media_license_token,course_is_drmed,media_sources,captions,thumbnail_sprite,slides,slide_urls,download_urls,external_url&q=0.9515943479253919`


  //external_url: '', download_urls:
  fetch(apiUrl)
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
      });
  }
  return response.json();
    })
    .then(data => {
      const formattedData = data;
      // Acessando campos específicos do objeto retornado pela API
      const asset = formattedData.asset || {};
      const thumbnail_sprite = asset.thumbnail_sprite || {};
      const vtt_url = thumbnail_sprite.vtt_url || '';
      const img_url = thumbnail_sprite.img_url || '';

      const captions = asset.captions || [];
      const captions_dict = captions[0] || {};
      const titulo_legenda = captions_dict.title || '';
      const url_legenda = captions_dict.url || '';
      const media_sources = asset.media_sources || '';
      const  media_sources_dict = media_sources[0] || '';
      const type_midia = media_sources_dict.type || '';
      const src = media_sources_dict.src || '';
      exibirDownloadButton(src,title)

        
    })
    .catch(error => {
      throw new Error(error)
    });
}



function obterDetalhes(id) {

  
  const btmn = document.getElementById('meus-cursos');
  btmn.style.visibility = 'visible';
  btmn.textContent = "Voltar para os Meus Cursos da Uemy";
  const apiUrl = `https://www.udemy.com/api-2.0/courses/${id}/subscriber-curriculum-items/?page_size=800&fields[lecture]=title,object_index,is_published,sort_order,created,asset,supplementary_assets,is_free&fields[quiz]=title,object_index,is_published,sort_order,type&fields[practice]=title,object_index,is_published,sort_order&fields[chapter]=title,object_index,is_published,sort_order&fields[asset]=title,filename,asset_type,status,time_estimation,is_external&caching_intent=True`;
  const existingDownloadButton = document.getElementById('downloadButton');
  
  if (existingDownloadButton){
  existingDownloadButton.remove()
}
  fetch(apiUrl)
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
      });
  }
  return response.json();
    })
    .then(data => {
      const results = data.results;

      const elementsList = document.createElement('div');

      results.forEach(item => {
        const itemElement = document.createElement('footer');
        itemElement.id = `item_${item.id}`; // Define um ID único para o elemento da aula

        if (item._class === 'chapter') {
          // Lógica para capítulos, se necessário
        } else if (item._class === 'lecture') {
          const lectureInfo = document.createElement('p');
          const supplementaryAssets = item.supplementary_assets || [];
          if (supplementaryAssets.length > 0) {
            const assetsDetailList = document.createElement('ul');
            supplementaryAssets.forEach(assetItem => {
              const titulo = assetItem.title;
              const assetId = assetItem.id;

              // Simulação da obtenção dos arquivos
            });
            lectureInfo.appendChild(assetsDetailList);
          }

          // Verifica se a aula é do tipo "article" para adicionar um botão especial
          const tipoAula = item.asset.asset_type;
          const linksButton = createStyledButton('Download');
          linksButton.id = "lnkbtns";
          
          if (tipoAula === 'article') {
            linksButton.textContent = `AULA - ${item.object_index} ${item.title} (Tipo: ${tipoAula})`;
            linksButton.addEventListener('click', function() {
              linksButton.style.background = "red";
              const a = obterFiles(id, item.id, item.title, item.asset.id);
            
            });
            itemElement.appendChild(linksButton);
          } else {
            linksButton.textContent = `AULA - ${item.object_index} ${item.title} (Tipo: ${tipoAula})`;
            linksButton.addEventListener('click', function() {
              linksButton.style.backgroundColor = "green"
              linksButton.remove()
              obterLinks(id, item.id, item.title);
            });
            itemElement.appendChild(linksButton);
          }

          const panel = document.getElementById('painel_');
          panel.innerHTML = '';
          panel.appendChild(itemElement); // Adiciona o elemento da aula no painel
          panel.appendChild(document.createElement('br'));
        }

        elementsList.appendChild(itemElement);
                    // Adiciona uma quebra de linha após cada botão
                    elementsList.appendChild(document.createElement('br'));
      });

      const panel = document.getElementById('painel_');
      panel.innerHTML = '';
      panel.appendChild(elementsList);


    })
    .catch(error => {
      console.error('Erro:', error);
      document.getElementById('painel_').innerText = `Ocorreu um erro ao buscar os detalhes do curso. ${error}`;
    });
}










function obterLinks(idCurso, idLecture,titulo) {
  
  const apiUrl = `https://www.udemy.com/api-2.0/users/me/subscribed-courses/${idCurso}/lectures/${idLecture}/?fields[lecture]=asset,description,download_url,is_free,last_watched_second&fields[asset]=asset_type,length,media_license_token,course_is_drmed,media_sources,captions,thumbnail_sprite,slides,slide_urls,download_urls,external_url&q=0.3108014137011559&&page_size=800&fields[lecture]=title,object_index,is_published,sort_order,created,asset,supplementary_assets,is_free&fields[quiz]=title,object_index,is_published,sort_order,type&fields[practice]=title,object_index,is_published,sort_order&fields[chapter]=title,object_index,is_published,sort_order&fields[asset]=title,filename,asset_type,status,time_estimation,is_external&caching_intent=True`;

  fetch(apiUrl)
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
      });
  }
  return response.json();
    })
    .then(data => {
      const formattedData = {}; // Objeto para armazenar os dados formatados

      // Converte a resposta em formato de dicionário
      Object.entries(data).forEach(([key, value]) => {
        formattedData[key] = value;
      });
      // Acessando campos específicos do objeto retornado pela API
      const asset = formattedData.asset || {};
      const thumbnail_sprite = asset.thumbnail_sprite || {};
      const vtt_url = thumbnail_sprite.vtt_url || '';
      const img_url = thumbnail_sprite.img_url || '';

      const captions = asset.captions || [];
      const captions_dict = captions[0] || {};
      const titulo_legenda = captions_dict.title || '';
      const url_legenda = captions_dict.url || '';
      const media_sources = asset.media_sources || '';
      const  media_sources_dict = media_sources[0] || '';
      const type_midia = media_sources_dict.type || '';
      const src = media_sources_dict.src || '';
      const asset_type = asset.asset_type || '';
      const lectureData = formattedData;
      const id_curso = lectureData.asset.id || ''
      const idAsset = lectureData.asset.id || ''
      const supplementary_assets = data.supplementary_assets || '';
      
   
      if(asset_type === 'Article'){
        const supplementary_assets_id = (data.supplementary_assets && data.supplementary_assets.length > 0) ? data.supplementary_assets[0].id : '';

        
        if(supplementary_assets_id){
      obterFiles(idCurso,idLecture,supplementary_assets_id,titulo);
       
        }
      else {
        // Extrair os IDs da aula e do ativo
const lectureId = lectureData.id;
const assetId = lectureData.asset.id;
        const results = obterArtigos(assetId,idCurso,lectureId,titulo)


        //exibirDownloadButton(src,titulo,'');
      }
      

    }
    else{
      obterVideos(idCurso,idLecture,titulo)


    }
    })
    .catch(error => {
      createPopupWithTimeout(`Não consegui obter os links das aulas : ${error}`,2000)
      document.getElementById('painel_').innerText = 'Ocorreu um erro ao buscar os links das aulas.'+`${error}`;
    });
}







function exibirDownloadButton(url, titulo, link) {
  // Verifica se o botão já existe
  let existingDownloadButton = document.getElementById('downloadButton');

  if (!existingDownloadButton) {
    // Cria um novo botão se ele ainda não existir
    const panel = document.createElement('div');
    panel.id = 'buttonPanel';
    panel.style.position = 'fixed'; // Posicionamento fixo
    panel.style.bottom = '20px'; // Ajusta a posição vertical
    panel.style.right = '20px'; // Ajusta a posição horizontal
    panel.style.zIndex = '999'; // Garante que fique acima de outros elementos

    // Botão para download
    const downloadButton = document.createElement('button');
    downloadButton.textContent = 'Download video';
    downloadButton.style.backgroundColor = 'green';
    downloadButton.style.width = '80px'; // Defina o tamanho desejado
    downloadButton.style.height = '50px'; // Defina o tamanho desejado
    downloadButton.id = 'downloadButton'; // Define um ID para o botão

    downloadButton.onclick = function () {
      const resp = "hlsNULL"
      baixarUsandoApiHck(url, titulo, link,resp);
      // Remove o botão após o clique
      panel.remove();
    };

    panel.appendChild(downloadButton);
    document.body.appendChild(panel);
  } else {
    // Se o botão já existe, apenas atualiza seu conteúdo
    existingDownloadButton.onclick = function () {
      const resp = "hlsNULL"
      baixarUsandoApiHck(url, titulo, link,resp);
      // Remove o botão após o clique
      existingDownloadButton.parentNode.remove();
    };
  }
}



function exibirDownloadButtonFILES(url) {
  // Verifica se o botão já existe
  let existingDownloadButton = document.getElementById('downloadButton2');

  if (!existingDownloadButton) {
    // Cria um novo botão se ele ainda não existir
    const panel = document.createElement('div');
    panel.id = 'buttonPanel1';
    panel.style.position = 'fixed'; // Posicionamento fixo
    panel.style.bottom = '20px'; // Ajusta a posição vertical
    panel.style.right = '20px'; // Ajusta a posição horizontal
    panel.style.zIndex = '999'; // Garante que fique acima de outros elementos

    // Botão para download
    const downloadButton = document.createElement('button');
    downloadButton.textContent = 'Download file';
    downloadButton.style.backgroundColor = 'green';
    downloadButton.style.width = '80px'; // Defina o tamanho desejado
    downloadButton.style.height = '50px'; // Defina o tamanho desejado
    downloadButton.id = 'downloadButton2'; // Define um ID para o botão
    
    downloadButton.onclick = function() {
      downloadFiles(url);
    };

    panel.appendChild(downloadButton);
    document.body.appendChild(panel);
  } else {
    // Se o botão já existe, apenas atualiza seu conteúdo
    existingDownloadButton.onclick = function() {
      downloadFiles(url);
    };
  }
}


function baixarUsandoApiHck(url,titulo,link,id='') {
  fetch('http://127.0.0.1:8842', {
    method: 'POST',
    body: JSON.stringify({ url: url,title: titulo,url2: link,id})
  })
    .then(response => response.json())
    .catch(error => {
     // Estilizando a mensagem de erro com HTML e CSS
const errorMessage = `Erro ao enviar os dados para: "ffmpeg server(localhost:8842)" Certifique-se de ter iniciado a aplicação!`;

// Exibindo o alerta com a mensagem estilizada
createPopupWithTimeout(errorMessage,8000);
    });
   
}
async function loginTrue() {
  try {
    const apiUrl = `https://www.udemy.com/api-2.0/contexts/me/?header=true&footer=true`;
    const response = await fetch(apiUrl);

    if (!response.ok) {
      const error = await response.json();
      createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`, 2000);
      throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
    }

    const data = await response.json();
    const logado = data.header.isLoggedIn;

    if (!logado) {
      const errorMessage = `<div style="border: 1px solid cyan; padding: 10px; margin: 10px; border-radius: 5px;"><a style="text-decoration: none; color: red; font-size: 10px;" href="https://www.udemy.com/join/login-popup/?" target="_blank">Login udemy</a>-> efetue o login, e tente usar a extensão.</div>`;
      
      document.getElementById('painel_').innerHTML = errorMessage;
      createPopupWithTimeout("ERRO: 'Obter-Courses-ERROR' (seção expirada)\n\n\nefetue o login em sua conta novamente ! ", 2000);
      return false; // Stop execution if the user is not logged in
    } else {
      return true;
    }
  } catch (error) {
    console.error(error);
    // Handle other errors here
    return false;
  }
}




document.getElementById('meus-cursos').addEventListener('click', function() {
  const apiUrl = "https://www.udemy.com/api-2.0/users/me/subscribed-courses/?page_size=100&ordering=-last_accessed&fields[course]=image_240x135,title,completion_ratio&is_archived=false";
const k = document.getElementById('meus-cursos-kiwify')

const bt = document.getElementById('meus-cursos-Nutror');
if (bt) {
  bt.remove()
}

if(k){
  k.remove();
}
  const existingDownloadButton = document.getElementById('downloadButton');
  
  if (existingDownloadButton){
  existingDownloadButton.remove()
}


loginTrue()


  fetch(apiUrl)
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.error}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.error}`);
      });
  }
  return response.json();
    })
    .then(data => {
      const results = data.results;
      const btmn = document.getElementById('meus-cursos');
      btmn.style.visibility = 'hidden';
      
      // Criando elementos HTML para cada curso
      const coursesList = document.createElement('ul');

      results.forEach(course => {
        const courseItem = document.createElement('li');

        const title = document.createElement('h3');
        title.textContent = course.title;
        courseItem.appendChild(title);

 
  
        const image = document.createElement('img');
        image.src = course.image_240x135;
        courseItem.appendChild(image);

        const completionRatio = document.createElement('p');
        completionRatio.textContent = `Taxa de conclusão: ${course.completion_ratio}%`;
        courseItem.appendChild(completionRatio);

        const detailsButton = document.createElement('button');
        detailsButton.textContent = 'Obter Detalhes';
        
        // Adiciona uma classe para o botão
        detailsButton.classList.add('custom-button');
        
        // Define estilos CSS para o botão e para o hover
        const buttonStyles = `
          background-color:  #ff7f50;
          color: #000;
        `;
        
        const hoverStyles = `
          background-color: #f00; /* Altere a cor de fundo para a cor desejada */
          color: #fff; /* Altere a cor do texto para a cor desejada */
        `;
        
        // Cria um elemento style para adicionar os estilos
        const styleElement = document.createElement('style');
        styleElement.textContent = `
          .custom-button {
            ${buttonStyles}
          }
          .custom-button:hover {
            ${hoverStyles}
          }
        `;
        
        // Adiciona os estilos ao head do documento
        document.head.appendChild(styleElement);
        
        // Adiciona o botão ao corpo do documento
        document.body.appendChild(detailsButton);
        

        
        detailsButton.addEventListener('click', function() {
          
          obterDetalhes(course.id);
        });
        courseItem.appendChild(detailsButton);

        coursesList.appendChild(courseItem);
        
    

        coursesList.appendChild(courseItem);
      
      });

      // Exibindo a lista de cursos no elemento com ID "painel_"
      const panel = document.getElementById('painel_');
      panel.innerHTML = ''; // Limpa o conteúdo existente
      panel.appendChild(coursesList);
    })
    .catch(error => {
      console.error('Erro:', error);
      document.getElementById('painel_').innerText = `ERRO INESPERADO: ${error}`;
      throw new Error(error);
    });
});












/////////// kiwify



function fetchCourses(authorizationToken) {
  
  const apiUrl = "https://api.kiwify.com.br/v1/viewer/schools/courses?&page=1&archived=false";

  const headers = new Headers();
  headers.append('Authorization', authorizationToken);
  headers.append('Content-Type', 'application/json');



  fetch(apiUrl, {
    headers: headers,
    credentials: 'omit'
  })
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        const errorMessage = `<div style="border: 1px solid cyan; padding: 10px; margin: 10px; border-radius: 5px;"><a style="text-decoration: none; color: red; font-size: 10px;" href="https://dashboard.kiwify.com.br/courses" target="_blank">Meus Cursos</a>-> Abra a página, e tente usar a extensão.</div>`;
      
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Messagem de ERRO: ${error.error}`,2000);
        document.getElementById('painel_').innerHTML = errorMessage;
          throw new Error(`HTTP error! Status: ${response.status}, ERRO: ${error.error}`);
        
      });
  }
  return response.json();
    })
    .then(data => {
      const coursesList = document.createElement('ul');
      coursesList.classList.add('courses-list'); // Adicione uma classe para estilização, se necessário https://dashboard.kiwify.com.br/courses

      data.courses.forEach(course => {
        const courseItem = document.createElement('li');
        courseItem.classList.add('course-item'); // Adicione uma classe para estilização, se necessário

        const courseId = course.course_info.id; // Obtém o ID do curso

        const title = document.createElement('h3');
        title.textContent = `${course.course_info.name}`; // Exibe o ID ao lado do título
        courseItem.appendChild(title);

        const image = document.createElement('img');
        image.src = course.course_info.course_img;
        courseItem.appendChild(image);

        const completionRatio = document.createElement('p');
        completionRatio.textContent = `Taxa de conclusão: ${course.course_info.completed_progress}%`;
        courseItem.appendChild(completionRatio);

        const detailsButton = document.createElement('button');
        detailsButton.textContent = 'Obter Detalhes';

        detailsButton.addEventListener('click', function() {
          obterDetalhesKiwify(courseId);
        });
        courseItem.appendChild(detailsButton);
                // Estilizando os botões e adicionando eventos para alterar o fundo quando o mouse passar por cima
                const buttonStyles = {
                  backgroundColor: '#ff7f50',
                  color: '#000',
                  padding: '8px 16px',
                  cursor: 'pointer',
                  border: 'none',
                  borderRadius: '4px',
                  margin: '4px'
                };
        
                applyButtonStyles(detailsButton, buttonStyles);




        coursesList.appendChild(courseItem); // Adiciona o item do curso à lista de cursos
      });

      const panel = document.getElementById('painel_');
      panel.innerHTML = ''; // Limpa o conteúdo existente
      panel.appendChild(coursesList); // Adiciona a lista de cursos ao painel
    })

}
function applyButtonStyles(button, styles) {
  for (const prop in styles) {
    button.style[prop] = styles[prop];
  }

  button.addEventListener('mouseover', function() {
    button.style.backgroundColor = '#ffa366'; // Altera o fundo quando o mouse passar por cima
  });

  button.addEventListener('mouseout', function() {
    button.style.backgroundColor = styles.backgroundColor; // Restaura o fundo original ao remover o mouse
  });
}

function obterVideosKiwify(hash_curso, lesson ,titulo) {
  const endpoint = `https://api.kiwify.com.br/v1/viewer/courses/${hash_curso}/lesson/${lesson}`;

  const authorizationToken = localStorage.getItem('Authorization');
  const headers = new Headers();
  headers.append('Authorization', authorizationToken);
  headers.append('Content-Type', 'application/json');

  fetch(endpoint, {
    headers: headers,
    credentials: 'omit'
  })
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.message}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.message}`);
      });
  }
  return response.json();
    })
    .then(data => {
      // Verifica se há um vídeo na resposta
      if (data.lesson && data.lesson.video) {
        const video = data.lesson.video;

        // URLs relacionadas ao vídeo
        const thumbnailURL = video.thumbnail;
        const downloadURL = video.download_link;
        const streamURL = video.stream_link;
        exibirDownloadButton(streamURL,titulo,"OLÁ CURIOSO(a)")
      }})
    .catch(error => {
      throw new Error(error);
    });
}



function exibirDetalhesCurso(curso,id_curso) {
  const panel = document.getElementById('painel_');
  panel.innerHTML = '';
  const btmn = document.getElementById('meus-cursos-kiwify')
  btmn.style.visibility = 'visible';
  btmn.textContent = "Voltar para os Meus Cursos da Kiwifi";

  const modules = curso.modules || [];

  modules.forEach(module => {
    const lessons = module.lessons || [];
    const moduleName = module.name;

    const moduleTitle = document.createElement('h3');
    moduleTitle.textContent = moduleName;


    lessons.forEach(lesson => {
      const lessonItem = document.createElement('div');
      lessonItem.classList.add('aula-item');

      const videoButton = createStyledButton('Download');
      videoButton.textContent = `AULA CAPITULO-${lesson.order} - ${lesson.title}`;
      videoButton.classList.add('video-button');

      // Adiciona um evento de clique ao botão para exibir informações da aula
      videoButton.addEventListener('click', function() {
        const videoInfo = lesson.video || {};
        const videoLink = videoInfo.stream_link || '';
        const files = lesson.files || [];
        const content = lesson.content || '';
        const lesson_id = lesson.id || '';
        
        if (videoLink === '') {
          criarArquivoHTML(content, lesson.title);
        } else {
          if (videoLink.startsWith("https://")) {
           // exibirDetalhesCurso("para resolver coloque em (f12) na pagina do video do seu curso clique em rede(networks) filtro coloque o valor copiado da url e veja qual requisicao equivale a ela ")
            exibirDownloadButton(videoLink, lesson.title, `${content} ${files}`);
          } else {
            // Corrigi o nome da variável "videolink" para "videoLink"
            //createPopupWithTimeout(`Servidor ausente na url do video : ${videoLink}`,4000);
          obterVideosKiwify(id_curso,lesson_id,lesson.title)
          
          }
        }
        
       videoButton.remove();
      });

      lessonItem.appendChild(videoButton);
      panel.appendChild(lessonItem);
            // Adiciona uma quebra de linha após cada botão
            panel.appendChild(document.createElement('br'));
    });
  });
}











function obterDetalhesKiwify(id_curso) {
  const authorizationToken = localStorage.getItem('Authorization');
  const endpoint = `https://api.kiwify.com.br/v1/viewer/courses/${id_curso}`;
  const headers = new Headers();
  headers.append('Authorization', authorizationToken);
  headers.append('Content-Type', 'application/json');

  fetch(endpoint, {
    headers: headers,
    credentials: 'omit'
  })
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message: ${error.message}`,2000)
          throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.message}`);
      });
  }
  return response.json();
    })
    .then(data => {
// Chame a função para exibir os detalhes do curso
exibirDetalhesCurso(data.course,id_curso);
    })
    .catch(error => {
      console.error('Erro:', error);
      document.getElementById('painel_').innerText = `KIWIFY ERRO 'Obter-Courses-ERROR': Ocorreu O erro  ${error}`;

    });
}




document.getElementById('meus-cursos-kiwify').addEventListener('click', function() {
  const authorizationToken = localStorage.getItem('Authorization');
  const btmn = document.getElementById('meus-cursos-kiwify');
  btmn.style.visibility = 'hidden';
const existingDownloadButton = document.getElementById('downloadButton');
const bbb = document.getElementById('meus-cursos')

const bt = document.getElementById('meus-cursos-Nutror');

  if (bt) {
  bt.remove()
}

if(bbb){
bbb.remove()
}
if (existingDownloadButton){
existingDownloadButton.remove()
}

if (authorizationToken){
    // Se houver um token de autorização salvo, buscar os cursos
    fetchCourses(authorizationToken);
  }

});










////////////// nutror
async function obterM3u8(token) {
  const authorizationToken = localStorage.getItem('Authorization');
  const url = `https://api.safevideo.com/player/watch?token=${token}`;
  try {
    const headers = new Headers();
    headers.append('Authorization', authorizationToken);
    headers.append('Content-Type', 'application/json');

    const response = await fetch(url, {
      method: 'GET',
      headers: headers
    });
    if (!response.ok) {
        return response.json().then(error => {
          createPopupWithTimeout(`HTTP error! Status: ${response.status}, Message de ERRO AO TENTAR OBTER LINKS DESTA AULA: ${error.message}`,2000)
            throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.message}`);
        });
    }
    if (response.ok) {
      const m3u8 = await response.json();
      const links = m3u8.playlist;
      const title = m3u8.title;

      return { "title":title,"url":links };
    } else {
      const errorMessage = await response.text();
      createPopupWithTimeout(`Ocorreu um erro ao buscar os links das aulas. ${errorMessage}`,2000)
      document.getElementById('painel_').innerText = 'Ocorreu um erro ao buscar os links das aulas.'+`${errorMessage}`;
      return {};
    }
  } catch (error) {
    createPopupWithTimeout(`Ocorreu um erro ao buscar os links das aulas. ${errorMessage}`,2000)
    document.getElementById('painel_').innerText = 'Ocorreu um erro ao buscar os links das aulas.'+`${error}`;
    return {};
  }
}


function criarArquivoHTML(textoHTML,title) {
  // Cria um blob com o texto HTML
  const blob = new Blob([textoHTML], { type: 'text/html' });

  // Cria um URL temporário para o Blob
  const blobUrl = URL.createObjectURL(blob);

  // Cria um link para download do arquivo
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = `${title}.html`; // Nome do arquivo a ser baixado
  link.click();

  // Limpa o URL temporário após o download do arquivo
  URL.revokeObjectURL(blobUrl);
}



function processarRespostaCurso(data) {
  const {
    course_title,
    title,
    description,
    release,
    contents
  } = data;

  if (contents && contents.length > 0) {
    contents.forEach(content => {
    });
  } else {
    createPopupWithTimeout(`Não há conteúdo disponível para esta aula.`)
    const erro = 'Não há conteúdo disponível para esta aula.';
    document.getElementById('painel_').innerText = `${erro}`;
    
  }
}












function extrairTokenDaUrl(url) {
  const padrao = /https:\/\/player2\.safevideo\.com\/([^/]+)/;
  const correspondencia = url.match(padrao);
  
  if (correspondencia && correspondencia.length > 1) {
    return correspondencia[1];
  } else {
    return null; // Retorna null se não encontrar um token na URL
  }
}




function obterLK(id_lesson) {
  const authorizationToken = localStorage.getItem('Authorization');
  const apiUrl = `https://learner-api.nutror.com/learner/lessons/${id_lesson}?forceManual=true`;

  const headers = new Headers();
  headers.append('Authorization', authorizationToken);
  headers.append('Content-Type', 'application/json');

  return fetch(apiUrl, {
    headers: headers,
    credentials: 'omit'
  })
  .then(response => {
    if (!response.ok) {
      return response.json().then(error => {
        const errorMessage = `<div style="border: 1px solid cyan; padding: 10px; margin: 10px; border-radius: 5px;"><a style="text-decoration: none; color: red; font-size: 10px;" href="https://app.nutror.com/cursos" target="_blank">Meus Cursos</a>-> Abra a página,clique no seu curso, e tente usar a extensão.[LEMBRE-SE DE DEIXAR O CURSO EM EXCUÇÃO OS VIDEOS.]</div>`;
      
        createPopupWithTimeout(`HTTP error! Status: ${response.status}, Messagem de ERRO: ${error.error}`,2000);
        document.getElementById('painel_').innerHTML = errorMessage;
          throw new Error(`HTTP error! Status: ${response.status}, ERRO: ${error.error}`);
        
      });
     } return response.json();
})
  .then(data => {
    // Tratamento dos dados recebidos da API
    if (data && data.data) {
      
      // Aqui você pode acessar os dados específicos conforme necessário
      const courseData = data.data;
      const status = courseData.status;
      if(status === "blocked"){
        document.getElementById('painel_').innerText = "Conteúdo bloqueado !"
        createPopupWithTimeout("Acesso ao conteúdo negado !,infelismente você não tem acesso a este conteúdo !",2000)
        throw new Error ("você não tem acesso a este conteúdo !")
      }
      

      // Exemplo: Acessar o título do curso
      const courseTitle = courseData.title;
      const lesson_type = courseData.lesson_type.name;

      if (courseData.contents && courseData.contents.length > 0) {
        const lesson = courseData.contents[0];
        const lessonEmbed = lesson.embed;
        if (lesson_type === "Texto"){
         criarArquivoHTML(lessonEmbed,courseTitle)
          
        }
        else{
  const token = extrairTokenDaUrl(lessonEmbed)
 
  if (!lessonEmbed.includes('safevideo')) {
    createPopupWithTimeout(`NUTROR ERRO 'Obter-urlVideo-ERROR': \nEste é um player que ainda não conheço por favor contate meu desenvolvedor REF:[${lessonEmbed}]`)
    document.getElementById('painel_').innerText = "NUTROR ERRO 'Obter-urlVideo-ERROR':\n\n\nplayer do video ainda não está em minhas funcionalidades.";

    throw new Error("Player inválido...");
  }
  // Chamada da função obterM3u8
  obterM3u8(token)
    .then(data => {
      // Utilize os dados obtidos da função
      const t = data.title;
      const ur = data.url;
      exibirDownloadButton(ur,t,"")
 
    })  
}  
      }
          // Verificação e exibição dos lesson_files, se existirem 
          const lesson = courseData;
          if (lesson.lesson_files || lesson.lesson_files.length > 0) {
           
            lesson.lesson_files.forEach(file => {
              const Nome =  file.title;
              const download = `https://learner-api.nutror.com${file.file_name}`
              downloadFiles(download,Nome);
              
            });
          }
        
      // Retornar os dados do curso para uso posterior, se necessário
      return courseData;
    }
  })

  
}







function exibirDetalhesCursonT(curso) {
  const bt = document.getElementById('meus-cursos-Nutror');
  if (bt) {
    bt.textContent = "Voltar para os Meus Cursos da Nutror";
    bt.style.visibility = 'visible';

  }
  
    

  
  const panel = document.getElementById('painel_');
  panel.innerHTML = '';
  
  
  const data = curso.data || [];

  data.forEach(item => {
    const lessons = item.lessons || [];
    const cursoTitle = item.title;

    const cursoTitleElement = document.createElement('h3');
    cursoTitleElement.textContent = cursoTitle;
    //panel.appendChild(cursoTitleElement);

    lessons.forEach(lesson => {
      const lessonItem = document.createElement('div');
      lessonItem.classList.add('aula-item');

      const lessonTitleElement = createStyledButton('Download');
      lessonTitleElement.textContent = `Aula - ${lesson.title}`;
      lessonTitleElement.classList.add('video-button');

      // Adiciona um evento de clique ao botão para exibir informações da aula
      lessonTitleElement.addEventListener('click', function() {
        const lessonInfo = lesson || {};
        const lessonID = lessonInfo.id || 'ID não disponível';
        const lessonType = lessonInfo.lesson_type.name || 'Tipo não disponível';
        const lessonStatus = lessonInfo.status || 'Status não disponível';
        const releaseDate = lessonInfo.release || 'Data de lançamento não disponível';
        const watched = lessonInfo.watched || false;
        lessonTitleElement.remove();
obterLK(lessonID);
     
     
      });

      lessonItem.appendChild(lessonTitleElement);
      panel.appendChild(lessonItem);
      // Adiciona uma quebra de linha após cada botão
      panel.appendChild(document.createElement('br'));
    });
  });
}



function obterDetalhesNutror(id_curso) {
  const authorizationToken = localStorage.getItem('Authorization');
  const endpoint = `https://learner-api.nutror.com/learner/course/${id_curso}/lessons/v2`;
  const headers = new Headers();
  headers.append('Authorization', authorizationToken);
  headers.append('Content-Type', 'application/json');
  fetch(endpoint, {
    headers: headers,
    credentials: 'omit'
  })
    .then(response => {
      if (!response.ok) {
        return response.json().then(error => {
          createPopupWithTimeout(`HTTP error! Status: ${response.status}, Messagem de ERRO: ${error.message}`,2000)
            throw new Error(`HTTP error! Status: ${response.status}, Message: ${error.message}`);
        });
    }
    return response.json();
})
    .then(data => {
// Chame a função para exibir os detalhes do curso
exibirDetalhesCursonT(data)
    })
    .catch(error => {
      // Lidar com o erro, como exibir uma mensagem de erro na interface do usuário
      document.getElementById('painel_').innerText = `NUTROR ERRO 'Obter-Courses-ERROR': ${error.message} COMO RESOLVER: abra a página 'meus cursos', selecione um curso e o abra, agora tente novamente usar a extensão.`;
    
    });
}

function fetchCoursesNt(authorizationToken) {
  const apiUrl = "https://learner-api.nutror.com/learner/course/search?page=1&size=20&hasParams=false&showShelf=true";
  const headers = new Headers();
  headers.append('Authorization', authorizationToken);
  headers.append('Content-Type', 'application/json');
  fetch(apiUrl, {
      headers: headers,
      credentials: 'omit'
  })
  .then(response => {
      if (!response.ok) {
        return response.json().then(error => {
          const errorMessage = `<div style="border: 1px solid cyan; padding: 10px; margin: 10px; border-radius: 5px;"><a style="text-decoration: none; color: red; font-size: 10px;" href="https://app.nutror.com/cursos" target="_blank">Meus Cursos</a>-> Abra a página,clique no seu curso, e tente usar a extensão.</div>`;
        
          createPopupWithTimeout(`HTTP error! Status: ${response.status}, Messagem de ERRO: ${error.message}`,2000);
          document.getElementById('painel_').innerHTML = errorMessage;
            throw new Error(`HTTP error! Status: ${response.status}, ERRO: ${error.message}`);
          
        });
      }
      return response.json();
      
  })
  
  .then(data => {

    const aviso = document.createElement("h1");
    aviso.style.color = 'red';
    aviso.style.fontSize = '14px'
    aviso.textContent = "deixe algun de seus cursos em excução para efetuar as consultas ! sem ser dectatdo como um robô"
    
      const coursesList = document.createElement('ul');
      coursesList.classList.add('courses-list');


      data.data.forEach(course => {

        
          const courseItem = document.createElement('li');
          courseItem.classList.add('course-item');

          const courseId = course.hash;
          const title = document.createElement('h3');
          title.textContent = `${course.title}`;
        
          

          const image = document.createElement('img');
          image.src = course.old_image;
          image.style.width = "100px";
          courseItem.appendChild(image);

          const completionRatio = document.createElement('p');
          completionRatio.textContent = `Taxa de conclusão: ${course.progress_percent}%`;
          courseItem.appendChild(completionRatio);

          const detailsButton = document.createElement('button');
          detailsButton.textContent = 'Obter Detalhes';

          detailsButton.addEventListener('click', function() {
              obterDetalhesNutror(courseId);
          });
          courseItem.appendChild(detailsButton);

          const buttonStyles = {
              backgroundColor: '#ff7f50',
              color: '#000',
              padding: '8px 16px',
              cursor: 'pointer',
              border: 'none',
              borderRadius: '4px',
              margin: '4px'
          };

          applyButtonStyles(detailsButton, buttonStyles);
      
          coursesList.appendChild(courseItem);
      });
      document.getElementById('avisos').style.display = 'block'
      document.getElementById('avisos').appendChild(aviso);






      
      const panel = document.getElementById('painel_');
      panel.innerHTML = '';
 
      panel.appendChild(coursesList);
  })

}




document.getElementById('meus-cursos-Nutror').addEventListener('click', function() {
        const authorizationToken = localStorage.getItem('Authorization');
        const btmn = document.getElementById('meus-cursos-kiwify');
      const existingDownloadButton = document.getElementById('downloadButton');
      const bbb = document.getElementById('meus-cursos')
      const bt = document.getElementById('meus-cursos-Nutror');
      
      if (bt) {
        bt.style.visibility = 'hidden';
      }
      if(bbb){
      bbb.remove()
      }
      if(btmn){
        btmn.remove()
      }
      if (existingDownloadButton){
      existingDownloadButton.remove()
      }
        if (authorizationToken) {
          // Se houver um token de autorização salvo, buscar os cursos
          fetchCoursesNt(authorizationToken);
        }
});




function createPopupWithTimeout(message, timeout) {
  // Criar div para o popup
  const popupDiv = document.createElement("div");

  // Estilizar o popup
  popupDiv.style.position = 'fixed';
  popupDiv.style.top = '50%';
  popupDiv.style.left = '50%';
  popupDiv.style.transform = 'translate(-50%, -50%)';
  popupDiv.style.width = '400px';
  popupDiv.style.padding = '20px';
  popupDiv.style.backgroundColor = '#f8d7da'; // Cor de fundo padrão (vermelho claro)
  popupDiv.style.color = '#721c24'; // Cor do texto (vermelho escuro)
  popupDiv.style.borderRadius = '8px';
  popupDiv.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
  popupDiv.style.zIndex = '9999';
  popupDiv.style.textAlign = 'center';

  // Criar parágrafo para a mensagem
  const popupMessage = document.createElement("p");

  // Estilizar a mensagem
  popupMessage.textContent = message;
  popupMessage.style.fontSize = '16px';
  popupMessage.style.marginBottom = '10px';

  // Adicionar a mensagem ao popup
  popupDiv.appendChild(popupMessage);

  // Criar botão de fechar
  const closeButton = document.createElement("button");
  closeButton.textContent = "Fechar";
  closeButton.style.marginRight = '10px';
  closeButton.style.padding = '8px 15px';
  closeButton.style.backgroundColor = '#dc3545'; // Cor de fundo do botão (vermelho)
  closeButton.style.color = 'white';
  closeButton.style.border = 'none';
  closeButton.style.borderRadius = '4px';
  closeButton.style.cursor = 'pointer';

  // Adicionar evento de clique ao botão de fechar
  closeButton.addEventListener('click', function() {
    popupDiv.style.display = 'none';
    popupDiv.remove();
  });

  // Adicionar botão de copiar erro
  const copyErrorButton = document.createElement("button");
  copyErrorButton.textContent = "Copiar Erro";
  copyErrorButton.style.padding = '8px 15px';
  copyErrorButton.style.backgroundColor = '#007bff'; // Cor de fundo do botão (azul)
  copyErrorButton.style.color = 'white';
  copyErrorButton.style.border = 'none';
  copyErrorButton.style.borderRadius = '2px';
  copyErrorButton.style.cursor = 'pointer';

  // Adicionar evento de clique ao botão de copiar erro
  copyErrorButton.addEventListener('click', function() {
    // Copiar a mensagem de erro para a área de transferência
    const textarea = document.createElement('textarea');
    textarea.value = message;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
  // Desabilitar o botão e alterar o texto após copiar
  copyErrorButton.disabled = true;
  copyErrorButton.textContent = "Copiado !";
  });

// Adicionar os botões ao popup
popupDiv.appendChild(copyErrorButton);
popupDiv.appendChild(document.createTextNode("           "));  // Adiciona um espaço como um nó de texto
popupDiv.appendChild(closeButton);


  // Adicionar o popup ao corpo do documento
  document.body.appendChild(popupDiv);

  // Definir uma contagem regressiva para fechar o popup automaticamente
  let countdown = 10;
  const countdownInterval = setInterval(function() {
    countdown--;
    closeButton.textContent = `Fechar (${countdown}s)`;
    if (countdown <= 0) {
      clearInterval(countdownInterval);
      popupDiv.style.display = 'none';
      popupDiv.remove();
    }
  }, 1000);
}

function criarPaginaApoie() {
  chrome.windows.create({
    url: 'apoiar.html',
    type: 'popup',
    width: 400,
    height: 600,
    left: 500,
    top: 500,
  });}
  
function criarPaginaHELP() {
  chrome.windows.create({
    url: 'ajuda.html',
    type: 'popup',
    width: 700,
    height: 600,
    left: 500,
    top: 500,
  });}
        

// Obter o elemento do link "Apoie" pelo ID e adicionar evento de clique
document.getElementById('linkApoie').addEventListener('click', function(event) {
  event.preventDefault(); // Impede o comportamento padrão do link
  criarPaginaApoie(); // Chama a função para criar a página de apoio
});

// Obter o elemento do link "Apoie" pelo ID e adicionar evento de clique
document.getElementById('gtc_help').addEventListener('click', function(event) {
  criarPaginaHELP(); // Chama a função para criar a página de apoio
});