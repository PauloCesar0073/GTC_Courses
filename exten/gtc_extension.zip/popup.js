// popup.js
// Adicione um ouvinte de evento ao ícone da extensão
 
    // Quando o ícone é clicado, abra o pop-up
    chrome.windows.create({
      url: 'popup.html',
      type: 'popup',
      width: 770,
      height: 600,
      left: 500,
      top: 500,
    });
