// Função para obter o valor atual do cabeçalho Authorization no localStorage
function getAuthorizationValue() {
  return localStorage.getItem('Authorization') || 'Xerro001';
}

chrome.webRequest.onBeforeSendHeaders.addListener(
  function(details) {
    const requestHeaders = details.requestHeaders;

    // Verifica se a requisição possui o cabeçalho Authorization
    const authorizationHeader = requestHeaders.find(header => header.name.toLowerCase() === 'authorization');

    if (authorizationHeader) {
      // Se a requisição contém o cabeçalho Authorization, salva o valor no localStorage
      const authorizationValue = authorizationHeader.value;
      localStorage.setItem('Authorization', authorizationValue);
    }

    // Obtém o valor atual do localStorage
    const storedAuthorization = getAuthorizationValue();

    // Adiciona o cabeçalho Authorization à requisição
    requestHeaders.push({ name: 'Authorization', value: storedAuthorization });

    // Continua a requisição com os cabeçalhos modificados
    return { requestHeaders: requestHeaders };
  },
  {
    urls: ["<all_urls>"],
    types: ["xmlhttprequest"]
  },
  ["blocking", "requestHeaders"]
);
