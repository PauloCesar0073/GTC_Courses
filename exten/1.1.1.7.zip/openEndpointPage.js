function abrirPaginaEndpoint(valor) {
    var valorApoioElement = document.getElementById('valorApoio');

    // Remova a classe 'erro' se ela existir
    valorApoioElement.classList.remove('erro');

    if (valor === '' || isNaN(valor) || parseFloat(valor) <= 0) {
        // Adicione a classe 'erro' e ajuste o texto da mensagem de erro
        valorApoioElement.classList.add('erro');
createPopupWithTimeout("Valor inválido !",2000)
        return;
    }

    var endpoint = `https://picpay.me/paulocesar0073/${valor}`;
    window.open(endpoint, '_blank');
}

document.getElementById('btnApoiar').addEventListener('click', function () {
    var valor = document.getElementById('valorApoio').value;

    abrirPaginaEndpoint(valor);
});


function createPopupWithTimeout(message, timeout) {
    // Criar div para o popup
    const popupDiv = document.createElement("div");
  
    // Estilizar o popup
    popupDiv.style.position = 'fixed';
    popupDiv.style.top = '50%';
    popupDiv.style.left = '50%';
    popupDiv.style.transform = 'translate(-50%, -50%)';
    popupDiv.style.width = '400px';
    popupDiv.style.padding = '20px';
    popupDiv.style.backgroundColor = '#f8d7da'; // Cor de fundo padrão (vermelho claro)
    popupDiv.style.color = '#721c24'; // Cor do texto (vermelho escuro)
    popupDiv.style.borderRadius = '8px';
    popupDiv.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
    popupDiv.style.zIndex = '9999';
    popupDiv.style.textAlign = 'center';
  
    // Criar parágrafo para a mensagem
    const popupMessage = document.createElement("p");
  
    // Estilizar a mensagem
    popupMessage.textContent = message;
    popupMessage.style.fontSize = '16px';
    popupMessage.style.marginBottom = '10px';
  
    // Adicionar a mensagem ao popup
    popupDiv.appendChild(popupMessage);
  
    // Criar botão de fechar
    const closeButton = document.createElement("button");
    closeButton.textContent = "Fechar";
    closeButton.style.marginRight = '10px';
    closeButton.style.padding = '8px 15px';
    closeButton.style.backgroundColor = '#dc3545'; // Cor de fundo do botão (vermelho)
    closeButton.style.color = 'white';
    closeButton.style.border = 'none';
    closeButton.style.borderRadius = '4px';
    closeButton.style.cursor = 'pointer';
  
    // Adicionar evento de clique ao botão de fechar
    closeButton.addEventListener('click', function() {
      popupDiv.style.display = 'none';
      popupDiv.remove();
    });
  

  
  
  // Adicionar os botões ao popup
  popupDiv.appendChild(document.createTextNode("           "));  // Adiciona um espaço como um nó de texto
  popupDiv.appendChild(closeButton);
  
  
    // Adicionar o popup ao corpo do documento
    document.body.appendChild(popupDiv);
  
    // Definir uma contagem regressiva para fechar o popup automaticamente
    let countdown = 10;
    const countdownInterval = setInterval(function() {
      countdown--;
      closeButton.textContent = `Fechar (${countdown}s)`;
      if (countdown <= 0) {
        clearInterval(countdownInterval);
        popupDiv.style.display = 'none';
        popupDiv.remove();
      }
    }, 1000);
  }
  